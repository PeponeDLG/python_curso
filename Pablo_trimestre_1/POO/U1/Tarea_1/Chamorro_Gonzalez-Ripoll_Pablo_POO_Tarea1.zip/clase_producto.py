# Definición de la clase Producto con sus propios atributos y métodos

class Producto:

    # Método constructor (método mágico)
    def __init__(self, identificador, nombre, categoria, precio, stock, stock_minimo):
        self.identificador = identificador
        self.nombre = nombre
        self.categoria = categoria
        self.precio = precio
        self.stock = stock
        self.stock_minimo = stock_minimo

    # Método mágico para mostrar datos de un producto
    def __str__(self):
        return f"Id: {self.identificador}\nNombre: {self.nombre}\nStock: {self.stock}"

    # Otros métodos
    def actualizar_stock(self, num_unidades):
        self.stock += num_unidades

    def esta_en_minimos(self):
        return self.stock < self.stock_minimo

    def __eq__(self, other):
        return self.identificador == other.identificador

class Producto:
    # Constructor de la clase
    def __init__(self, nombre:str, precio:float):
        
        if precio<0:
            raise ValueError("El precio del producto no puede ser negativo")
        
        self.__nombre = nombre
        self.__precio = precio
    
    # Métodos getters 

    @property
    def get_nombre(self):
        return self.__nombre
    
    @property
    def get_precio(self):
        return self.__precio
    
    def __str__(self):
        return f"Producto(Nombre='{self.__nombre}', Precio={self.__precio:.2f})"
    
    def __eq__(self, producto):
        if self.__nombre == producto.__nombre and self.__precio == producto.__precio:
            return True

        return False

        

class Carrito:
    def __init__(self):
        self.__carrito = []
    
    def agregar(self, producto: Producto, unidades:int=1):
        if unidades < 1:
            raise ValueError("El número de unidades debe ser mayor que 0")
        
        for i in range(unidades):
            self.__carrito.append(producto)
    
    def eliminar(self,producto:Producto,unidades:int=1):
        if unidades < 1:
            raise ValueError("El número de unidades debe ser mayor que 0")

        unid_eliminadas = 0

        for p in self.__carrito: 
            if p == producto and unid_eliminadas < unidades:
                self.__carrito.remove(p)
                unid_eliminadas+=1
    
    def vaciar(self):
        self.__carrito = []
    
    def total(self):
        
        importe_total = 0

        for p in self.__carrito:
            importe_total+=p.get_precio
        
        return importe_total

    def listar(self):

        cesta = []        
        # Recorro el carrito
        for p in self.__carrito:
            encontrado = False
            for pc in cesta:
                if p == pc[0]:
                    encontrado = True
                    pc[1]+=1
                    break
            
            if not encontrado:
                cesta.append([p,1])
        
        # Mostramos la cesta
        for producto in cesta:
            print(f"- {producto[0].get_nombre} x {producto[1]} (Precio Unidad: {producto[0].get_precio}) -> Precio Subtotal {producto[0].get_precio*producto[1] }")

                        




    
    
    


    
    

    


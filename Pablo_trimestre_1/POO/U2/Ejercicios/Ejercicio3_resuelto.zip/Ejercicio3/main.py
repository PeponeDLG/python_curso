from clases import Producto, Carrito
class Main:
    @staticmethod
    def main():

        try:
            
            # Creo los productos
            p1 = Producto("Libro", 15.50)
            p2 = Producto("Lápiz", 2)
            p3 = Producto("Cuaderno", 3)
            p4 = Producto("Libro", 15.50)
            
            # los añado al carrito
            c1 = Carrito()

            c1.agregar(p1,2)
            c1.agregar(p2,2)
            c1.agregar(p3)
            # c1.agregar(p4)

            # c1.eliminar(p1,2)
            
            print("Listado de la cesta")
            c1.listar()
            print(f"Total.: {c1.total()}")

        except ValueError as e:
            print (e)
        except Exception as e:
            print(e)

if __name__ == "__main__":
    Main.main()
